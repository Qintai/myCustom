﻿/*
*  创建人：喔是传奇 
*  Date: 2019-10-14 14:38:30
*/

using System;

namespace crud_web
{
/*    public class delegateDemo: System.MulticastDelegate
    {
        public delegate int kkk(int a,int b);

        public delegateDemo(object target, string method) : base(target, method)
        {
            // 反编译看IL
            //Action m = new Action(() => { });
        }

        public delegateDemo(Type target, string method) : base(target, method)
        {
        }
        
    }*/
}