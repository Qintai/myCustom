﻿//using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace MyStandard
{
    public class IEnumerableTest
    {
       
    }
}
